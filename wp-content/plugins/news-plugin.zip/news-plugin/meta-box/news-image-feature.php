<?php 
  echo "Hello Every One ";
?>