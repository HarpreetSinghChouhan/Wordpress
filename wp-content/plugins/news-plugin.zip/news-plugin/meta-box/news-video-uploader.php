<?php 

echo  " hello every one this is video uploder file";
?>